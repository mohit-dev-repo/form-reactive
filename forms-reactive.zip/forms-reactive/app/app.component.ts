import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  genders = ['male', 'female'];
  signupForm: FormGroup;
  submitted = false;
  user = {
    username: '',
    email: '',
    gender: ''
  };

  constructor() {}

  ngOnInit() {
    this.signupForm = new FormGroup({
      'userData': new FormGroup({
        'username': new FormControl(null, [Validators.required]),
        'email': new FormControl(null, [Validators.required, Validators.email])
      }),
      'gender': new FormControl('male'),
    });
    this.signupForm.setValue({
      'userData': {
        'username': 'Mohit',
        'email': 'mohit@test.com'
      },
      'gender': 'male'
    });
    this.signupForm.patchValue({
      'userData': {
        'username': 'Rohit',
      }
    });
  }

  onSubmit() {
    this.submitted = true;
    this.user.username = this.signupForm.controls.userData.value.username;
    this.user.email = this.signupForm.controls.userData.value.email;
    this.user.gender = this.signupForm.controls.gender.value;
    this.signupForm.reset();
  }

}
